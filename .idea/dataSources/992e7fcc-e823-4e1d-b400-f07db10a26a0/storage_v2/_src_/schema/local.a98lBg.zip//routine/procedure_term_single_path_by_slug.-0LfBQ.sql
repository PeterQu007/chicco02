create
    definer = root@localhost procedure procedure_term_single_path_by_slug(IN slug varchar(50))
BEGIN
WITH RECURSIVE category_path (term_id, name, slug, parent) AS
(
  SELECT taxo.term_id, tm.name, tm.slug, parent
    FROM wp_term_taxonomy taxo
    INNER JOIN wp_terms tm ON tm.term_id = taxo.term_id
    WHERE tm.slug = slug  -- child node
  UNION ALL
  SELECT taxo.term_id, tm.name, tm.slug, taxo.parent
    FROM category_path AS cp JOIN wp_term_taxonomy AS taxo
      ON cp.parent = taxo.term_id
	INNER JOIN wp_terms tm ON tm.term_id = taxo.term_id
)
SELECT level, term_id, name, slug, parent, N.neighborhood_name, N.neighborhood_code
FROM
(SELECT (ROW_NUMBER() OVER ())-1 level, term_id, name, slug, parent
FROM category_path) AS c
INNER JOIN pid_neighborhoods N ON N.neighborhood_name = c.name
Order by level;
END;

