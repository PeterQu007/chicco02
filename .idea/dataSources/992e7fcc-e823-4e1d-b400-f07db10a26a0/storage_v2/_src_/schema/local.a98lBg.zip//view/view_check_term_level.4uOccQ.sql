create view view_check_term_level as
with recursive `category_path` (`term_id`, `slug`, `description`, `lvl`) as (select `tm`.`term_id`                           AS `term_id`,
                                                                                    `tm`.`slug`                              AS `slug`,
                                                                                    `local`.`wp_term_taxonomy`.`description` AS `description`,
                                                                                    0                                        AS `lvl`
                                                                             from (`local`.`wp_term_taxonomy`
                                                                                      join `local`.`wp_terms` `tm`
                                                                                           on ((`tm`.`term_id` = `local`.`wp_term_taxonomy`.`term_id`)))
                                                                             where (`local`.`wp_term_taxonomy`.`parent` = 0)
                                                                             union all
                                                                             select `t`.`term_id`     AS `term_id`,
                                                                                    `tm`.`slug`       AS `slug`,
                                                                                    `t`.`description` AS `description`,
                                                                                    (`cp`.`lvl` + 1)  AS `cp.lvl + 1`
                                                                             from (`category_path` `cp`
                                                                                      join (`local`.`wp_term_taxonomy` `t` join `local`.`wp_terms` `tm` on ((`tm`.`term_id` = `t`.`term_id`)))
                                                                                           on ((`cp`.`term_id` = `t`.`parent`))))
select `category_path`.`term_id`     AS `term_id`,
       `category_path`.`slug`        AS `slug`,
       `category_path`.`description` AS `description`,
       `category_path`.`lvl`         AS `lvl`
from `category_path`
order by `category_path`.`lvl`;

