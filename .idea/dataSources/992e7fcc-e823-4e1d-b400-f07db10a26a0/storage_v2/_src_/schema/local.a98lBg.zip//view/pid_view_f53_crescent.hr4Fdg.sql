create view pid_view_f53_crescent as
select `local`.`pid_market`.`Date`                   AS `Date`,
       cast(group_concat(if((`local`.`pid_market`.`Neighborhood_ID` = 'F53'), `local`.`pid_market`.`HPI`, NULL)
                         separator ',') as unsigned) AS `HPI`,
       cast(group_concat(
               if((`local`.`pid_market`.`Neighborhood_ID` = 'F53'), `local`.`pid_market`.`Ave_Sales_Price`, NULL)
               separator ',') as unsigned)           AS `Ave Price`,
       cast(group_concat(
               if((`local`.`pid_market`.`Neighborhood_ID` = 'F53'), `local`.`pid_market`.`Med_Sales_Price`, NULL)
               separator ',') as unsigned)           AS `Med Price`
from `local`.`pid_market`
where ((`local`.`pid_market`.`Date` >= '2015-01-01') and (`local`.`pid_market`.`Neighborhood_ID` = 'F53'))
group by `local`.`pid_market`.`Date`;

