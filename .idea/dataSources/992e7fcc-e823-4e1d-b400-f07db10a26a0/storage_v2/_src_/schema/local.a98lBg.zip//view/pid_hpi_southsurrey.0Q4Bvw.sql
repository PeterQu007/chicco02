create view pid_hpi_southsurrey as
select `local`.`pid_market`.`Date` AS `Date`,
       group_concat(if((`local`.`pid_market`.`Neighborhood_ID` = 'F50'), `local`.`pid_market`.`HPI`, NULL) separator
                    ',')           AS `South Surrey`,
       group_concat(if((`local`.`pid_market`.`Neighborhood_ID` = 'F51'), `local`.`pid_market`.`HPI`, NULL) separator
                    ',')           AS `F51`
from `local`.`pid_market`
group by `local`.`pid_market`.`Date`;

