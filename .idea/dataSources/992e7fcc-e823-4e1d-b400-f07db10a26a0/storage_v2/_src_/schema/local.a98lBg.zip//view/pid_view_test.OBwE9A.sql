create view pid_view_test as
select `local`.`pid_cities`.`City_ID`   AS `City_ID`,
       `local`.`pid_cities`.`City_Code` AS `City_Code`,
       `local`.`pid_cities`.`City_Name` AS `City_Name`,
       `local`.`pid_cities`.`Region_ID` AS `Region_ID`
from `local`.`pid_cities`;

